const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');

// Adatbázis kapcsolat létrehozása
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',   // Az adatbázis felhasználó (pl. "root")
    password: '',   // Az adatbázis jelszó (ha szükséges)
    database: 'yelp_clone'  // Az adatbázis neve
});

// Kapcsolódás tesztelése
db.connect((err) => {
    if (err) {
        console.error('Hiba az adatbázishoz való kapcsolódáskor: ' + err.stack);
        return;
    }
    console.log('Sikeresen kapcsolódva az adatbázishoz!');
});

// Express alkalmazás létrehozása
const app = express();
const port = 6600;

// Body parser middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Statikus fájlok kiszolgálása
app.use(express.static('public'));

// Vélemények betöltése az adatbázisból
app.get('/reviews', (req, res) => {
    db.query('SELECT * FROM reviews ORDER BY id DESC', (err, results) => {
        if (err) {
            res.status(500).json({ message: 'Hiba történt a vélemények betöltésekor' });
            return;
        }
        res.json(results);
    });
});

// Új vélemény hozzáadása
app.post('/reviews', (req, res) => {
    const { name, rating, review } = req.body;

    if (name && rating >= 1 && rating <= 5 && review) {
        const query = 'INSERT INTO reviews (name, rating, review) VALUES (?, ?, ?)';
        db.query(query, [name, rating, review], (err, result) => {
            if (err) {
                res.status(500).json({ message: 'Hiba történt a vélemény hozzáadásakor' });
                return;
            }
            res.status(201).json({ id: result.insertId, name, rating, review });
        });
    } else {
        res.status(400).json({ message: 'Érvénytelen adat' });
    }
});

// Szerver indítása
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
